#include <SFML/Graphics.hpp>
#include <astra/astra.hpp>
#include <iostream>
#include <cstring>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <string>
#include <time.h>

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_PORT 43893
#define SERVER_IP "192.168.1.120"

using namespace std;
string posture = "";
string message = "unknown";
int cont = 0;
float rHand[3][3];
float waist[3][3];
float manDis = 0;
float angle = 0;
int handInstruct = 0;
int follow = 0;
int acc = 0;
float FPS = 0;
float handsmove = 0;
float waistmove = 0;
float handsmove2 = 0;
time_t upDowntime = time(NULL);
time_t turnaroundtime = time(NULL);
int isPlane = 0;
int turnLeftState = 0;
int turnRightState = 0;
int client_fd;
struct sockaddr_in ser_addr;
socklen_t addrLen = sizeof(*(struct sockaddr *)&ser_addr);
namespace user_command
{
    uint32_t upOrDown = 1;
    uint32_t rotate = 9;
    uint32_t move = 10;
    int zeroVal = 0;
    int leftRotateVal = -15000;
    int rightRotateVal = 15000;
    int selfLeftRotateVal = -7000;
    int selfRightRotateVal = 7000;
    int backVal = -10000;
    int forwardVal = 10000;
}
struct CommandHead
{
    uint32_t code;
    union
    {
        int value;
        int paramters_size;
    };
    struct
    {
        uint32_t type : 8;
        uint32_t count : 24;
    };
};
struct CommandHead command_head = {0};

class sfLine : public sf::Drawable
{
public:
    sfLine(const sf::Vector2f &point1, const sf::Vector2f &point2, sf::Color color, float thickness)
        : color_(color)
    {
        const sf::Vector2f direction = point2 - point1;
        const sf::Vector2f unitDirection = direction / std::sqrt(direction.x * direction.x + direction.y * direction.y);
        const sf::Vector2f normal(-unitDirection.y, unitDirection.x);

        const sf::Vector2f offset = (thickness / 2.f) * normal;

        vertices_[0].position = point1 + offset;
        vertices_[1].position = point2 + offset;
        vertices_[2].position = point2 - offset;
        vertices_[3].position = point1 - offset;

        for (int i = 0; i < 4; ++i)
            vertices_[i].color = color;
    }

    void draw(sf::RenderTarget &target, sf::RenderStates states) const
    {
        target.draw(vertices_, 4, sf::Quads, states);
    }

private:
    sf::Vertex vertices_[4];
    sf::Color color_;
};


void robotMove(double fps, long double frameDuration);
void turnLeft(int state);
void turnRight(int state);

class BodyVisualizer : public astra::FrameListener
{
public:
    BodyVisualizer()
    {
        font_.loadFromFile("Inconsolata.otf");
    }

    static sf::Color get_body_color(std::uint8_t bodyId)
    {
        if (bodyId == 0)
        {
            // Handle no body separately - transparent
            return sf::Color(0x00, 0x00, 0x00, 0x00);
        }
        // Case 0 below could mean bodyId == 25 or
        // above due to the "% 24".
        switch (bodyId % 24)
        {
        case 0:
            return sf::Color(0x00, 0x88, 0x00, 0xFF);
        case 1:
            return sf::Color(0x00, 0x00, 0xFF, 0xFF);
        case 2:
            return sf::Color(0x88, 0x00, 0x00, 0xFF);
        case 3:
            return sf::Color(0x00, 0xFF, 0x00, 0xFF);
        case 4:
            return sf::Color(0x00, 0x00, 0x88, 0xFF);
        case 5:
            return sf::Color(0xFF, 0x00, 0x00, 0xFF);

        case 6:
            return sf::Color(0xFF, 0x88, 0x00, 0xFF);
        case 7:
            return sf::Color(0xFF, 0x00, 0xFF, 0xFF);
        case 8:
            return sf::Color(0x88, 0x00, 0xFF, 0xFF);
        case 9:
            return sf::Color(0x00, 0xFF, 0xFF, 0xFF);
        case 10:
            return sf::Color(0x00, 0xFF, 0x88, 0xFF);
        case 11:
            return sf::Color(0xFF, 0xFF, 0x00, 0xFF);

        case 12:
            return sf::Color(0x00, 0x88, 0x88, 0xFF);
        case 13:
            return sf::Color(0x00, 0x88, 0xFF, 0xFF);
        case 14:
            return sf::Color(0x88, 0x88, 0x00, 0xFF);
        case 15:
            return sf::Color(0x88, 0xFF, 0x00, 0xFF);
        case 16:
            return sf::Color(0x88, 0x00, 0x88, 0xFF);
        case 17:
            return sf::Color(0xFF, 0x00, 0x88, 0xFF);

        case 18:
            return sf::Color(0xFF, 0x88, 0x88, 0xFF);
        case 19:
            return sf::Color(0xFF, 0x88, 0xFF, 0xFF);
        case 20:
            return sf::Color(0x88, 0x88, 0xFF, 0xFF);
        case 21:
            return sf::Color(0x88, 0xFF, 0xFF, 0xFF);
        case 22:
            return sf::Color(0x88, 0xFF, 0x88, 0xFF);
        case 23:
            return sf::Color(0xFF, 0xFF, 0x88, 0xFF);
        default:
            return sf::Color(0xAA, 0xAA, 0xAA, 0xFF);
        }
    }

    void init_depth_texture(int width, int height)
    {
        if (displayBuffer_ == nullptr || width != depthWidth_ || height != depthHeight_)
        {
            depthWidth_ = width;
            depthHeight_ = height;
            int byteLength = depthWidth_ * depthHeight_ * 4;

            displayBuffer_ = BufferPtr(new uint8_t[byteLength]);
            std::memset(displayBuffer_.get(), 0, byteLength);

            texture_.create(depthWidth_, depthHeight_);
            sprite_.setTexture(texture_, true);
            sprite_.setPosition(0, 0);
        }
    }

    void init_overlay_texture(int width, int height)
    {
        if (overlayBuffer_ == nullptr || width != overlayWidth_ || height != overlayHeight_)
        {
            overlayWidth_ = width;
            overlayHeight_ = height;
            int byteLength = overlayWidth_ * overlayHeight_ * 4;

            overlayBuffer_ = BufferPtr(new uint8_t[byteLength]);
            std::fill(&overlayBuffer_[0], &overlayBuffer_[0] + byteLength, 0);

            overlayTexture_.create(overlayWidth_, overlayHeight_);
            overlaySprite_.setTexture(overlayTexture_, true);
            overlaySprite_.setPosition(0, 0);
        }
    }

    void check_fps()
    {
        double fpsFactor = 0.02;

        std::clock_t newTimepoint = std::clock();
        long double frameDuration = (newTimepoint - lastTimepoint_) / static_cast<long double>(CLOCKS_PER_SEC);

        frameDuration_ = frameDuration * fpsFactor + frameDuration_ * (1 - fpsFactor);
        lastTimepoint_ = newTimepoint;
        double fps = 1.0 / frameDuration_;
        FPS = fps;
   	
	cout<< " FPS: " << fps << "(" << frameDuration_ << ")\n";
	isPlane = 0;
	if(isPlane == 0){
		if(turnLeftState == 0){
			command_head.code = user_command::rotate;
		    	command_head.value = user_command::zeroVal;
			sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
			turnLeftState = 1;
		}else if(turnRightState == 0){
			command_head.code = user_command::rotate;
		    	command_head.value = user_command::zeroVal;
			sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
			turnRightState = 1;
		}else{
        	robotMove(fps, frameDuration_);
        }
	}else if(isPlane == 1){
		turnLeft(turnLeftState);
	}else if(isPlane == 2){
		turnRight(turnRightState);
	}

        //posture+="FPS:";
        //stringstream out1;
        //out1<<fixed<<setprecision(3)<<fps;
        //string s10 = out1.str();
        //posture+=s10;
        //posture+="\n";
    }

    void processDepth(astra::Frame &frame)
    {
        const astra::DepthFrame depthFrame = frame.get<astra::DepthFrame>();

        if (!depthFrame.is_valid())
        {
            return;
        }

        int width = depthFrame.width();
        int height = depthFrame.height();

        init_depth_texture(width, height);

        const int16_t *depthPtr = depthFrame.data();
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                int index = (x + y * width);
                int index4 = index * 4;

                int16_t depth = depthPtr[index];
                uint8_t value = depth % 255;

                displayBuffer_[index4] = value;
                displayBuffer_[index4 + 1] = value;
                displayBuffer_[index4 + 2] = value;
                displayBuffer_[index4 + 3] = 255;
            }
        }

        texture_.update(displayBuffer_.get());
    }

    void processBodies(astra::Frame &frame)
    {
        astra::BodyFrame bodyFrame = frame.get<astra::BodyFrame>();

        jointPositions_.clear();
        circles_.clear();
        circleShadows_.clear();
        boneLines_.clear();
        boneShadows_.clear();

        if (!bodyFrame.is_valid() || bodyFrame.info().width() == 0 || bodyFrame.info().height() == 0)
        {
            clear_overlay();
            return;
        }

        const float jointScale = bodyFrame.info().width() / 120.f;

        const auto &bodies = bodyFrame.bodies();

        for (auto &body : bodies)
        {
            // printf("Processing%d frame #%d body %d left hand: %u\n",
            //   bodyFrame.frame_index(), body.id(), unsigned(body.hand_poses().left_hand()),body.id());
            //printf("frame_index:%d \nbody_id:%d \ncenter_of_mass:%f %f %f  \n",
            //    bodyFrame.frame_index(), body.id(), body.center_of_mass().x, body.center_of_mass().y, body.center_of_mass().z);
            //for (auto& joint : body.joints())
            //{
            //    printf("joint_info:\ntype:%d\nworld_position:%f %f %f\ndepth_position:%f %f\n",
            //        joint.type(), joint.world_position().x, joint.world_position().y, joint.world_position().z, joint.depth_position().x, joint.depth_position().y);
            //    jointPositions_.push_back(joint.depth_position());
            //}

            manDis = sqrt(body.joints()[9].world_position().x * body.joints()[9].world_position().x + body.joints()[9].world_position().z * body.joints()[9].world_position().z);

            if (body.center_of_mass().y - body.joints()[12].world_position().y < 400)
            {
                message = "accident";
		acc = 1;
            }
            else
            {
                message = "safe";
		acc = 0;
            }
            posture += "\ndistance:";
            manDis = manDis / 1000.0;
            stringstream out;
            //recongnize rHand action
            cont++;
            int timeStamp = (int) FPS/3;
            if (cont == 100)
            {
                cont = 0;
            }
            if(cont%timeStamp==0){
            float handX = ((rHand[2][0] - rHand[1][0])+(rHand[1][0]-rHand[0][0]))/2;
            float handY = ((rHand[2][1] - rHand[1][1])+(rHand[1][1]-rHand[0][1]))/2;
            float handZ = ((rHand[2][2] - rHand[1][2])+(rHand[1][2]-rHand[0][2]))/2;
            float waistX = ((waist[2][0] - waist[1][0])+(waist[1][0]-waist[0][0]))/2;
            float waistZ = ((waist[2][2] - waist[1][2])+(waist[1][2]-waist[0][2]))/2;
            float waistM = sqrt(waistX*waistX+waistZ*waistZ);
            handsmove = handY;
            waistmove = waistM;
            handsmove2 = handX;
            cout << "handY:"<<handY<<" waistM:"<<waistM<<" handX:"<<handX<<"\n";
            if(rHand[0][0]!=0&&rHand[1][0]!=0&&rHand[2][0]!=0){
                if(handY>220||handY<-220){
                    time_t now = time(NULL);
                    //if(now-upDowntime>=3){
                        //upDowntime = now;
                        //handInstruct = 1;
                        //cout << "hands up and down";
                    //}
                }
            else if((waistM<50&&waistM>-50) && (handX>200||handX<-200)){
                    time_t now = time(NULL);
                    //if(now-turnaroundtime>20){
                    //handInstruct = 2;
                    //turnaroundtime = now;
                    //cout << "hands turnaround";                        
                    //}
                 }
            }
            if((waistM<50&&waistM>-50) && (handZ>150||handZ<-150))
                follow = 1;
            }
            if(body.joints()[7].world_position().y>body.joints()[0].world_position().y && body.joints()[4].world_position().y>body.joints()[0].world_position().y){
                follow = 0;
            }
            
            //out<<fixed<<setprecision(3)<<manDis;
            string s5 = out.str();
            posture += s5;

            posture += "m\nangle:";
            posture += "\nsafe";

            stringstream out2;
            if (cont%timeStamp==0)
            {
            rHand[0][0] = body.joints()[7].world_position().x;
            rHand[0][1] = body.joints()[7].world_position().y;
            rHand[0][2] = body.joints()[7].world_position().z;
            waist[0][0] = body.joints()[9].world_position().x;
            waist[0][1] = body.joints()[9].world_position().y;
            waist[0][2] = body.joints()[9].world_position().z;
            }
            angle = atan2(body.joints()[9].world_position().z, body.joints()[9].world_position().x);
            angle = body.joints()[9].world_position().x;
            //out2<<fixed<<setprecision(3)<<angle;
            s5 = out2.str();
            posture += s5;
            if (cont%timeStamp==0)
            {
            for (size_t i = 2; i > 0; i--)
            {
                for (size_t j = 0; j < 3; j++)
                {
                    rHand[i][j] = rHand[i - 1][j];
                    waist[i][j] = waist[i - 1][j];
                }
            }  
            }
            update_body(body, jointScale);
        }
        const auto &floor = bodyFrame.floor_info(); //floor
        if (floor.floor_detected())
        {
            const auto &p = floor.floor_plane();
            // std::cout << "Floor plane: ["
            //           << p.a() << ", " << p.b() << ", " << p.c() << ", " << p.d()
            //           << "]" << std::endl;
        }

        const auto &bodyMask = bodyFrame.body_mask();
        const auto &floorMask = floor.floor_mask();

        update_overlay(bodyMask, floorMask);
    }

    void update_body(astra::Body body,
                     const float jointScale)
    {
        const auto &joints = body.joints();

        if (joints.empty())
        {
            return;
        }

        for (const auto &joint : joints)
        {
            astra::JointType type = joint.type();
            const auto &pos = joint.depth_position();

            if (joint.status() == astra::JointStatus::NotTracked)
            {
                continue;
            }

            auto radius = jointRadius_ * jointScale; // pixels
            sf::Color circleShadowColor(0, 0, 0, 255);

            auto color = sf::Color(0x00, 0xFF, 0x00, 0xFF);

            if ((type == astra::JointType::LeftHand && astra::HandPose::Grip == body.hand_poses().left_hand()) ||
                (type == astra::JointType::RightHand && astra::HandPose::Grip == body.hand_poses().right_hand()))
            {
                radius *= 1.5f;
                circleShadowColor = sf::Color(255, 255, 255, 255);
                color = sf::Color(0x00, 0xAA, 0xFF, 0xFF);
            }

            const auto shadowRadius = radius + shadowRadius_ * jointScale;
            const auto radiusDelta = shadowRadius - radius;

            sf::CircleShape circle(radius);

            circle.setFillColor(sf::Color(color.r, color.g, color.b, 255));
            circle.setPosition(pos.x - radius, pos.y - radius);
            circles_.push_back(circle);

            sf::CircleShape shadow(shadowRadius);
            shadow.setFillColor(circleShadowColor);
            shadow.setPosition(circle.getPosition() - sf::Vector2f(radiusDelta, radiusDelta));
            circleShadows_.push_back(shadow);
        }

        update_bone(joints, jointScale, astra::JointType::Head, astra::JointType::Neck);
        update_bone(joints, jointScale, astra::JointType::Neck, astra::JointType::ShoulderSpine);

        update_bone(joints, jointScale, astra::JointType::ShoulderSpine, astra::JointType::LeftShoulder);
        update_bone(joints, jointScale, astra::JointType::LeftShoulder, astra::JointType::LeftElbow);
        update_bone(joints, jointScale, astra::JointType::LeftElbow, astra::JointType::LeftWrist);
        update_bone(joints, jointScale, astra::JointType::LeftWrist, astra::JointType::LeftHand);

        update_bone(joints, jointScale, astra::JointType::ShoulderSpine, astra::JointType::RightShoulder);
        update_bone(joints, jointScale, astra::JointType::RightShoulder, astra::JointType::RightElbow);
        update_bone(joints, jointScale, astra::JointType::RightElbow, astra::JointType::RightWrist);
        update_bone(joints, jointScale, astra::JointType::RightWrist, astra::JointType::RightHand);

        update_bone(joints, jointScale, astra::JointType::ShoulderSpine, astra::JointType::MidSpine);
        update_bone(joints, jointScale, astra::JointType::MidSpine, astra::JointType::BaseSpine);

        update_bone(joints, jointScale, astra::JointType::BaseSpine, astra::JointType::LeftHip);
        update_bone(joints, jointScale, astra::JointType::LeftHip, astra::JointType::LeftKnee);
        update_bone(joints, jointScale, astra::JointType::LeftKnee, astra::JointType::LeftFoot);

        update_bone(joints, jointScale, astra::JointType::BaseSpine, astra::JointType::RightHip);
        update_bone(joints, jointScale, astra::JointType::RightHip, astra::JointType::RightKnee);
        update_bone(joints, jointScale, astra::JointType::RightKnee, astra::JointType::RightFoot);
    }

    void update_bone(const astra::JointList &joints,
                     const float jointScale, astra::JointType j1,
                     astra::JointType j2)
    {
        const auto &joint1 = joints[int(j1)];
        const auto &joint2 = joints[int(j2)];

        if (joint1.status() == astra::JointStatus::NotTracked ||
            joint2.status() == astra::JointStatus::NotTracked)
        {
            //don't render bones between untracked joints
            return;
        }

        //actually depth position, not world position
        const auto &jp1 = joint1.depth_position();
        const auto &jp2 = joint2.depth_position();

        auto p1 = sf::Vector2f(jp1.x, jp1.y);
        auto p2 = sf::Vector2f(jp2.x, jp2.y);

        sf::Color color(255, 255, 255, 255);
        float thickness = lineThickness_ * jointScale;
        if (joint1.status() == astra::JointStatus::LowConfidence ||
            joint2.status() == astra::JointStatus::LowConfidence)
        {
            color = sf::Color(128, 128, 128, 255);
            thickness *= 0.5f;
        }

        boneLines_.push_back(sfLine(p1,
                                    p2,
                                    color,
                                    thickness));
        const float shadowLineThickness = thickness + shadowRadius_ * jointScale * 2.f;
        boneShadows_.push_back(sfLine(p1,
                                      p2,
                                      sf::Color(0, 0, 0, 255),
                                      shadowLineThickness));
    }

    void update_overlay(const astra::BodyMask &bodyMask,
                        const astra::FloorMask &floorMask)
    {
        const auto *bodyData = bodyMask.data();
        const auto *floorData = floorMask.data();
        const int width = bodyMask.width();
        const int height = bodyMask.height();

        init_overlay_texture(width, height);

        const int length = width * height;

        for (int i = 0; i < length; i++)
        {
            const auto bodyId = bodyData[i];
            const auto isFloor = floorData[i];

            sf::Color color(0x0, 0x0, 0x0, 0x0);

            if (bodyId != 0)
            {
                color = get_body_color(bodyId);
            }
            else if (isFloor != 0)
            {
                color = sf::Color(0x0, 0x0, 0xFF, 0x88);
            }

            const int rgbaOffset = i * 4;
            overlayBuffer_[rgbaOffset] = color.r;
            overlayBuffer_[rgbaOffset + 1] = color.g;
            overlayBuffer_[rgbaOffset + 2] = color.b;
            overlayBuffer_[rgbaOffset + 3] = color.a;
        }

        overlayTexture_.update(overlayBuffer_.get());
    }

    void clear_overlay()
    {
        int byteLength = overlayWidth_ * overlayHeight_ * 4;
        std::fill(&overlayBuffer_[0], &overlayBuffer_[0] + byteLength, 0);

        overlayTexture_.update(overlayBuffer_.get());
    }

    virtual void on_frame_ready(astra::StreamReader &reader,
                                astra::Frame &frame) override
    {

        check_fps();
        if (isPaused_)
        {
            return;
        }

        processDepth(frame);
        processBodies(frame);
        const astra::DepthFrame depthFrame = frame.get<astra::DepthFrame>();
        const int16_t* depthPtr = depthFrame.data();
	int width = depthFrame.width();
        int height = depthFrame.height();
        ransac(depthPtr, 2, 15, width, height);
	isPlane = obstacleDetection(depthPtr, width, height);
	
    }

    int obstacleDetection(const int16_t* depthPtr, int width, int height){
	int tt = width*height;
	int zerocnt = 0;
	int totalxsleft = 0;
	int totalxsright = 0;
	for(int i = 0; i < tt; i++){
	    if (depthPtr[i]==0){
		zerocnt += 1;
		int f = i % width;
		if(f<width/16){
		    totalxsleft += 1;
		}else if(f>15*width/16){
		    totalxsright += 1;
		}
	    }
	}
	float zeroDetect = (float)zerocnt/((float)tt);
	float leftDetect = (float)totalxsleft/((float)tt)*16;
	float rightDetect = (float)totalxsright/((float)tt)*16;
	if (zeroDetect > 0.8){
	    cout << "find plane" << endl;
	    return 2; // all obstacle
	}else if(leftDetect > 0.6&&leftDetect>rightDetect){
	    cout << "left obstacle" << endl;
	    return 1; // left obstacle, should turn left
	}else if(rightDetect > 0.6&&leftDetect<rightDetect){
	    cout << "right obstacle" << endl;
	    return 2; // right obstacle, should turn right
	}
	return 0; // no obstacle
    }

    void ransac(const int16_t* depthPtr, int max_iter, float thr, int width, int height) {
        srand(time(0));
        int size_old[4];
        size_old[0] = 3;
        size_old[1] = 3;
        size_old[2] = 3;
        size_old[3] = 3;
        double as[4];
        double bs[4];
        double cs[4];
        double ds[4];
        as[0] = -1;
        as[1] = -1;
        as[2] = -1;
        as[3] = -1;
        bs[0] = -1;
        bs[1] = -1;
        bs[2] = -1;
        bs[3] = -1;
        cs[0] = -1;
        cs[1] = -1;
        cs[2] = -1;
        cs[3] = -1;
        ds[0] = -1;
        ds[1] = -1;
        ds[2] = -1;
        ds[3] = -1;
        double a, b, c, d;
        int tt = width * height;
        int* cnt;
        cnt = (int*)malloc(307200 * sizeof(int));
        for (int l = 0; l < 307200; l++)
        {
            cnt[l] = 0;
        }
        //left plane
        int p1, p2, p3;
        double x1, x2, x3, y1, y2, y3, z1, z2, z3;
        int fitp;
        int store = max_iter;
        while (--store) {
            int s1 = rand() % (height/3);
            int s2 = rand() % (height/3);
            int s3 = rand() % (height/3);
            while (s3 == s1)
            {
                s3 = rand() % (height/3);
            }
            /*p1 = (int)(width / 16 + (s1+height/3) * width);
            p2 = (int)(width / 8 + (s2+height/3) * width);
            p3 = (int)(width / 16 + (s3+height/3) * width);*/
            p1 = (int)(width / 16 + (height / 3) * width);
            p2 = (int)(width / 8 + (height / 2) * width);
            p3 = (int)(width / 16 + (2*height / 3) * width);
            x1 = (double)(p1 % width);
            y1 = (double)(p1 / width);
            z1 = (double)depthPtr[p1];
            x2 = (double)(p2 % width);
            y2 = (double)(p2 / width);
            z2 = (double)depthPtr[p2];
            x3 = (double)(p3 % width);
            y3 = (double)(p3 / width);
            z3 = (double)depthPtr[p3];
            a = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
            b = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
            c = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
            d = -(a * x1 + b * y1 + c * z1);
            fitp = 0;
            for (int i = 0; i < tt; i++) {
                double dis = fabs(a * (i % width) + b * (i / width) + c * (depthPtr[i]) + d) / sqrt(a * a + b * b + c * c);
                if (dis < thr)
                {
                    fitp += 1;
                }
            }
            if (fitp > size_old[0])
            {
                size_old[0] = fitp;
                as[0] = a;
                bs[0] = b;
                cs[0] = c;
                ds[0] = d;
            }
        }
        //right plane
        store = max_iter;
        while (--store) {
            int s1 = rand() % (height/3);
            int s2 = rand() % (height/3);
            int s3 = rand() % (height/3);
            while (s3 == s1)
            {
                s3 = rand() % (height/3);
            }
            /*p1 = (int)(15 * width / 16 + (s1+height/3) * width);
            p2 = (int)(7 * width / 8 + (s2+height/3) * width);
            p3 = (int)(15 * width / 16 + (s3+height/3) * width);*/
            p1 = (int)(15 * width / 16 + (height / 3) * width);
            p2 = (int)(7 * width / 8 + (height / 2) * width);
            p3 = (int)(15 * width / 16 + (2*height / 3) * width);
            x1 = (double)(p1 % width);
            y1 = (double)(p1 / width);
            z1 = (double)depthPtr[p1];
            x2 = (double)(p2 % width);
            y2 = (double)(p2 / width);
            z2 = (double)depthPtr[p2];
            x3 = (double)(p3 % width);
            y3 = (double)(p3 / width);
            z3 = (double)depthPtr[p3];
            a = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
            b = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
            c = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
            d = -(a * x1 + b * y1 + c * z1);
            fitp = 0;
            for (int i = 0; i < tt; i++) {
                double dis = fabs(a * (i % width) + b * (i / width) + c * (depthPtr[i]) + d) / sqrt(a * a + b * b + c * c);
                if (dis < thr)
                {
                    fitp += 1;
                }
            }
            if (fitp > size_old[1])
            {
                size_old[1] = fitp;
                as[1] = a;
                bs[1] = b;
                cs[1] = c;
                ds[1] = d;
            }
        }
        //up plane
        store = max_iter;
        while (--store) {
            int s1 = rand() % (width/3);
            int s2 = rand() % (width/3);
            int s3 = rand() % (width/3);
            while (s3 == s1)
            {
                s3 = rand() % (width/3);
            }
            /*p1 = (int)(s1+width/3 + height / 16 * width);
            p2 = (int)(s2+width/3 + height / 8 * width);
            p3 = (int)(s3+width/3 + height / 16 * width);*/
            p1 = (int)(width / 3 + height / 16 * width);
            p2 = (int)(width / 2 + height / 8 * width);
            p3 = (int)(2*width / 3 + height / 16 * width);
            x1 = (double)(p1 % width);
            y1 = (double)(p1 / width);
            z1 = (double)depthPtr[p1];
            x2 = (double)(p2 % width);
            y2 = (double)(p2 / width);
            z2 = (double)depthPtr[p2];
            x3 = (double)(p3 % width);
            y3 = (double)(p3 / width);
            z3 = (double)depthPtr[p3];
            a = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
            b = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
            c = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
            d = -(a * x1 + b * y1 + c * z1);
            fitp = 0;
            for (int i = 0; i < tt; i++) {
                double dis = fabs(a * (i % width) + b * (i / width) + c * (depthPtr[i]) + d) / sqrt(a * a + b * b + c * c);
                if (dis < thr)
                {
                    fitp += 1;
                }
            }
            if (fitp > size_old[2])
            {
                size_old[2] = fitp;
                as[2] = a;
                bs[2] = b;
                cs[2] = c;
                ds[2] = d;
            }
        }
        //front plane
        store = max_iter;
        while (--store) {
            int s1 = rand() % (height/8);
            int s2 = rand() % (width / 8);
            int s3 = rand() % (height/8);
            int s4 = rand() % (width / 8);
            while (s3 == s1)
            {
                s3 = rand() % (height/8);
            }
            while (s4 == s2) {
                s4 = rand() % (width / 8);
            }
            p1 = (int)(7 * width / 16 + s2 + (7 * height / 16 + s1) * width);
            p2 = (int)(7 * width / 16 + s2 + (7 * height / 16 + s3) * width);
            p3 = (int)(7 * width / 16 + s4 + (7 * height / 16 + s1) * width);
            x1 = (double)(p1 % width);
            y1 = (double)(p1 / width);
            z1 = (double)depthPtr[p1];
            x2 = (double)(p2 % width);
            y2 = (double)(p2 / width);
            z2 = (double)depthPtr[p2];
            x3 = (double)(p3 % width);
            y3 = (double)(p3 / width);
            z3 = (double)depthPtr[p3];
            a = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
            b = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
            c = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
            d = -(a * x1 + b * y1 + c * z1);
            fitp = 0;
            for (int i = 0; i < tt; i++) {
                double dis = fabs(a * (i % width) + b * (i / width) + c * (depthPtr[i]) + d) / sqrt(a * a + b * b + c * c);
                if (dis < thr)
                {
                    fitp += 1;
                }
            }
            if (fitp > size_old[2])
            {
                size_old[2] = fitp;
                as[2] = a;
                bs[2] = b;
                cs[2] = c;
                ds[2] = d;
            }
        }
        //draw
        float planethr = 0.5;
        if (size_old[0]>30000 && (cs[0] <planethr || -cs[0] < planethr ||bs[0]<planethr||-bs[0]<planethr||as[0]<planethr||-as[0]<planethr))
        {
            for (int i = 0; i < tt; i++) {
                double dis = fabs(as[0] * (i % width) + bs[0] * (i / width) + cs[0] * (depthPtr[i]) + ds[0]) / sqrt(as[0] * as[0] + bs[0] * bs[0] + cs[0] * cs[0]);
                if (dis < thr && depthPtr[i]!=0)
                {
                    sf::Color color = sf::Color(255, 0, 0, 0x88);
                    const int rgbaOffset = i * 4;
                    overlayBuffer_[rgbaOffset] = color.r;
                    overlayBuffer_[rgbaOffset + 1] = color.g;
                    overlayBuffer_[rgbaOffset + 2] = color.b;
                    overlayBuffer_[rgbaOffset + 3] = color.a;
                }
            }
        }
        if (size_old[1] > 30000 && (cs[1] < planethr || -cs[1] < planethr || bs[1] < planethr || -bs[1] < planethr || as[1] < planethr || -as[1] < planethr))
        {
            for (int i = 0; i < tt; i++) {
                double dis = fabs(as[1] * (i % width) + bs[1] * (i / width) + cs[1] * (depthPtr[i]) + ds[1]) / sqrt(as[1] * as[1] + bs[1] * bs[1] + cs[1] * cs[1]);
                if (dis < thr && depthPtr[i] != 0)
                {
                    sf::Color color = sf::Color(255, 255, 0, 0x88);
                    const int rgbaOffset = i * 4;
                    overlayBuffer_[rgbaOffset] = color.r;
                    overlayBuffer_[rgbaOffset + 1] = color.g;
                    overlayBuffer_[rgbaOffset + 2] = color.b;
                    overlayBuffer_[rgbaOffset + 3] = color.a;
                }
            }
        }
        if (size_old[2] > 30000 && (cs[2] < planethr || -cs[2] < planethr || bs[2] < planethr || -bs[2] < planethr || as[2] < planethr || -as[2] < planethr))
        {
            for (int i = 0; i < tt; i++) {
                double dis = fabs(as[2] * (i % width) + bs[2] * (i / width) + cs[2] * (depthPtr[i]) + ds[2]) / sqrt(as[2] * as[2] + bs[2] * bs[2] + cs[2] * cs[2]);
                if (dis < thr && depthPtr[i] != 0)
                {
                    sf::Color color = sf::Color(0, 255, 0, 0x88);
                    const int rgbaOffset = i * 4;
                    overlayBuffer_[rgbaOffset] = color.r;
                    overlayBuffer_[rgbaOffset + 1] = color.g;
                    overlayBuffer_[rgbaOffset + 2] = color.b;
                    overlayBuffer_[rgbaOffset + 3] = color.a;
                }
            }
        }
        if (size_old[3] > 30000 && (cs[3] < planethr || -cs[3] < planethr || bs[3] < planethr || -bs[3] < planethr || as[3] < planethr || -as[3] < planethr))
        {
            for (int i = 0; i < tt; i++) {
                double dis = fabs(as[3] * (i % width) + bs[3] * (i / width) + cs[3] * (depthPtr[i]) + ds[3]) / sqrt(as[3] * as[0] + bs[3] * bs[3] + cs[3] * cs[3]);
                if (dis < thr && depthPtr[i] != 0)
                {
                    sf::Color color = sf::Color(0, 255, 255, 0x88);
                    const int rgbaOffset = i * 4;
                    overlayBuffer_[rgbaOffset] = color.r;
                    overlayBuffer_[rgbaOffset + 1] = color.g;
                    overlayBuffer_[rgbaOffset + 2] = color.b;
                    overlayBuffer_[rgbaOffset + 3] = color.a;
                }
            }
        }
        overlayTexture_.update(overlayBuffer_.get());
        free(cnt);
    }

    void draw_bodies(sf::RenderWindow &window)
    {
        const float scaleX = window.getView().getSize().x / overlayWidth_;
        const float scaleY = window.getView().getSize().y / overlayHeight_;

        sf::RenderStates states;
        sf::Transform transform;
        transform.scale(scaleX, scaleY);
        states.transform *= transform;

        for (const auto &bone : boneShadows_)
            window.draw(bone, states);

        for (const auto &c : circleShadows_)
            window.draw(c, states);

        for (const auto &bone : boneLines_)
            window.draw(bone, states);

        for (auto &c : circles_)
            window.draw(c, states);
    }

    void draw_text(sf::RenderWindow &window,
                   sf::Text &text,
                   sf::Color color,
                   const int x,
                   const int y) const
    {
        text.setColor(sf::Color::Black);
        text.setPosition(x + 5, y + 5);
        window.draw(text);

        text.setColor(color);
        text.setPosition(x, y);
        window.draw(text);
    }

    void draw_help_message(sf::RenderWindow &window) const
    {
        if (!isMouseOverlayEnabled_)
        {
            return;
        }

        std::stringstream str;
        //str << posture;
        str << "\nhandX:" << handsmove2 << " \nwaistM:" << waistmove << "\nstatus:" << message << "\nfollow:" << follow;
        //  << "1handY:" << handsmove
        if (isFullHelpEnabled_ && helpMessage_ != nullptr)
        {
            str << "\n"
                << helpMessage_;
        }

        const int characterSize = 50;
        sf::Text text(str.str(), font_);
        text.setCharacterSize(characterSize);
        text.setStyle(sf::Text::Bold);

        const float displayX = 0.f;
        const float displayY = 0;
	if(acc == 1){
			draw_text(window, text, sf::Color::Red, displayX, displayY);
		}
        else draw_text(window, text, sf::Color::White, displayX, displayY);
    }

    void draw_to(sf::RenderWindow& window)
    {
       if (displayBuffer_ != nullptr)
       {
           const float scaleX = window.getView().getSize().x / depthWidth_;
           const float scaleY = window.getView().getSize().y / depthHeight_;
           sprite_.setScale(scaleX, scaleY);

           window.draw(sprite_); // depth
       }

       if (overlayBuffer_ != nullptr)
       {
           const float scaleX = window.getView().getSize().x / overlayWidth_;
           const float scaleY = window.getView().getSize().y / overlayHeight_;
           overlaySprite_.setScale(scaleX, scaleY);
           window.draw(overlaySprite_); //bodymask and floormask
       }

       draw_bodies(window);
       draw_help_message(window);
    }

    void toggle_paused()
    {
        isPaused_ = !isPaused_;
    }

    bool is_paused() const
    {
        return isPaused_;
    }

    void toggle_overlay()
    {
        isMouseOverlayEnabled_ = !isMouseOverlayEnabled_;
    }

    bool overlay_enabled() const
    {
        return isMouseOverlayEnabled_;
    }

    void toggle_help()
    {
        isFullHelpEnabled_ = !isFullHelpEnabled_;
    }

    void set_help_message(const char *msg)
    {
        helpMessage_ = msg;
    }

private:
    long double frameDuration_{0};
    std::clock_t lastTimepoint_{0};
    sf::Texture texture_;
    sf::Sprite sprite_;
    sf::Font font_;

    using BufferPtr = std::unique_ptr<uint8_t[]>;
    BufferPtr displayBuffer_{nullptr};

    std::vector<astra::Vector2f> jointPositions_;

    int depthWidth_{0};
    int depthHeight_{0};
    int overlayWidth_{0};
    int overlayHeight_{0};

    std::vector<sfLine> boneLines_;
    std::vector<sfLine> boneShadows_;
    std::vector<sf::CircleShape> circles_;
    std::vector<sf::CircleShape> circleShadows_;

    float lineThickness_{0.5f}; // pixels
    float jointRadius_{1.0f};   // pixels
    float shadowRadius_{0.5f};  // pixels

    BufferPtr overlayBuffer_{nullptr};
    sf::Texture overlayTexture_;
    sf::Sprite overlaySprite_;

    bool isPaused_{false};
    bool isMouseOverlayEnabled_{true};
    bool isFullHelpEnabled_{false};
    const char *helpMessage_{nullptr};
};

astra::DepthStream configure_depth(astra::StreamReader &reader)
{
    auto depthStream = reader.stream<astra::DepthStream>();

    //We don't have to set the mode to start the stream, but if you want to here is how:
    astra::ImageStreamMode depthMode;

    depthMode.set_width(640);
    depthMode.set_height(480);
    depthMode.set_pixel_format(astra_pixel_formats::ASTRA_PIXEL_FORMAT_DEPTH_MM);
    depthMode.set_fps(30);

    depthStream.set_mode(depthMode);

    return depthStream;
}

int rotateState = 0;
void squat()
{
    command_head.code = user_command::upOrDown; // 指令码
    command_head.value = user_command::zeroVal;
    sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
}
int fc = 0;
bool np = false;
bool turnaround = false;

void turnLeft(int state){
	if(state == 0){
	    	command_head.code = user_command::rotate;
	    	command_head.value = user_command::zeroVal;
		sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
		turnLeftState = 1;
	}
	else{
	    	command_head.code = user_command::rotate;
	    	command_head.value = user_command::leftRotateVal;
		sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
		turnLeftState = 0;
	}
	
}

void turnRight(int state){
	if(state == 0){
	    	command_head.code = user_command::rotate;
	    	command_head.value = user_command::zeroVal;
		sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
		turnRightState = 1;
	}
	else{
	    	command_head.code = user_command::rotate;
	    	command_head.value = user_command::rightRotateVal;
		sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
		turnRightState = 0;
	}
	
}

void robotMove(double fps, long double frameDuration)
{
    command_head.code = user_command::rotate;
    command_head.value = user_command::zeroVal;
    angle = 0;
    if(handInstruct == 1){
        handInstruct = 0;
        command_head.code = user_command::upOrDown;
    }
    else if(handInstruct == 2){
        handInstruct = 0;
        command_head.code = user_command::rotate;
        command_head.value = user_command::selfLeftRotateVal; //left
        rotateState = 1;
        turnaround = true;
    }
    else if (angle > 80 && rotateState != 1)
    {
        fc = 0;
        command_head.code = user_command::rotate;
        command_head.value = user_command::leftRotateVal; //left
        rotateState = 1;
    }
    else if (angle < -80 && rotateState != -1)
    {
        fc = 0;
        command_head.code = user_command::rotate;
        command_head.value = user_command::rightRotateVal; //right
        rotateState = -1;
    }
    else
    {
        fc = fc + 1;
        if (fc < 3)
        {
            rotateState = 0;
            command_head.code = user_command::rotate;
            command_head.value = user_command::zeroVal;
        }
        else
        {
            command_head.code = user_command::move;
            if (manDis > 2.8 && follow == 1)
            {
                //command_head.value = user_command::forwardVal;
            }
            else
            {
                command_head.value = user_command::zeroVal;
            }
        }
    }
    cout << "rotate: " << command_head.value;

    if (fps > 15)
    {
        if (np)
            np = false;
        else
        {
            np = true;
            sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
            if(turnaround){
                turnaround = false;
                cout << "start time:" <<time(NULL);
                usleep(5500000);
                cout << "\nend time:" <<time(NULL);
                command_head.value = user_command::zeroVal;
                sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
            }
        }
    }
    else
    {
        sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
        if(turnaround){
                turnaround = false;
                cout << "start time:" <<time(NULL);
                usleep(5500000);
                cout << "\nend time:" <<time(NULL);
                command_head.value = user_command::zeroVal;
                sendto(client_fd, &command_head, sizeof(command_head), 0, (struct sockaddr *)&ser_addr, addrLen);
            }
    }
}

int main(int argc, char **argv)
{
    sf::RenderWindow window(sf::VideoMode(1280, 960), "Simple Body Viewer");
    // create socket udp
    client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_fd < 0)
    {
        printf("create socket fail!\n");
        return -1;
    }
    memset(&ser_addr, 0, sizeof(ser_addr));
    ser_addr.sin_family = AF_INET;
    ser_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
    ser_addr.sin_port = htons(SERVER_PORT);
    //--------------------------------------------------------------------
    cout << "Do the dog need to stand up?(yes or no)";
    string standUp = "";
    while (cin >> standUp)
    {
        if (standUp == "yes")
        {
            squat();
            break;
        }
        else if (standUp == "no")
            break;
    }

    //--------------------------------------------------------------------
    for (size_t i = 0; i < 3; i++)
    {
        for (size_t j = 0; j < 3; j++)
        {
            rHand[i][j] = 0;
        }
    }
    astra::initialize();

    if (argc == 2)
    {
        FILE *fp = fopen(argv[1], "rb");
        char licenseString[1024] = {0};
        fread(licenseString, 1, 1024, fp);
        orbbec_body_tracking_set_license(licenseString);

        fclose(fp);
    }
    else
    {
        const char *licenseString = "7QpqAnYc1T4cQXV6kApUxdmATp6dkezf6aKWM25ejT6rHZAEM+w+Tfc+D0U2Agn5zTXeyHMI5NtMQjYfID9DCk5hbWU9uai5+rv5fE9yZz2wwrHIxNqyv3xDb21tZW50PXtjb21tZW50OsTasr+y4srULGN1c3RvbWVyX3R5cGU6b3JkaW5hcnksbGljZW5zZV90eXBlOm9mZmxpbmUsdmVyc2lvbjoxfXxFeHBpcmF0aW9uPTE2NDczMTQxMjI=";
        orbbec_body_tracking_set_license(licenseString);
    }

    astra::StreamSet sensor;
    astra::StreamReader reader = sensor.create_reader();

    BodyVisualizer listener;

    auto depthStream = configure_depth(reader);
    depthStream.start();

    auto bodyStream = reader.stream<astra::BodyStream>();
    bodyStream.start();
    reader.add_listener(listener);

    astra::BodyTrackingFeatureFlags features = astra::BodyTrackingFeatureFlags::HandPoses;

    int picCnt = 0;
    while (window.isOpen())
    {
        astra_update();
        // clear the window with black color
        window.clear(sf::Color::Black);

        listener.draw_to(window);
        window.display();
    }
    astra::terminate();
    return 0;
}

